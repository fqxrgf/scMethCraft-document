scMethCraft.function package
============================

Submodules
----------

scMethCraft.function.DMR module
-------------------------------

.. automodule:: scMethCraft.function.DMR
   :members:
   :undoc-members:
   :show-inheritance:

scMethCraft.function.annotation module
--------------------------------------

.. automodule:: scMethCraft.function.annotation
   :members:
   :undoc-members:
   :show-inheritance:

scMethCraft.function.batch module
---------------------------------

.. automodule:: scMethCraft.function.batch
   :members:
   :undoc-members:
   :show-inheritance:

scMethCraft.function.embedding module
-------------------------------------

.. automodule:: scMethCraft.function.embedding
   :members:
   :undoc-members:
   :show-inheritance:

scMethCraft.function.enhancement module
---------------------------------------

.. automodule:: scMethCraft.function.enhancement
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: scMethCraft.function
   :members:
   :undoc-members:
   :show-inheritance:
