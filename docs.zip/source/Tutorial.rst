Tutorial
=================

.. toctree::
   :maxdepth: 2
   :caption: Tutorial

   Training Data Generation
   Model Training
   Dimensionality Reduction
   Data Enhancement
   Batch Integration
   Cell type annotation