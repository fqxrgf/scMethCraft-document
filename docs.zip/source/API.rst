API
=================

.. toctree::
   :maxdepth: 2
   :caption: API

   scMethCraft.benchmark
   scMethCraft.function
   scMethCraft.model
   scMethCraft.postprecessing
   scMethCraft.preprocessing
